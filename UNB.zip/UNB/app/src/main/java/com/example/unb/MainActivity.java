package com.example.unb;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.TableRow;
import android.content.Context;
import android.widget.Button;
import android.widget.CheckBox;
import org.jetbrains.annotations.NotNull;
import java.io.IOException;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {
    private TextView mtextvireresult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mtextvireresult=findViewById(R.id.out_result);
        OkHttpClient client=new OkHttpClient();
        String url ="https://api.nike.com/product_feed/threads/v2/?filter=marketplace%28DE%29&filter=language%28de%29&filter=channelId%28010794e5-35fe-4e32-aaff-cd2c74f89d61%29";
        Request request = new Request.Builder()
                .url(url)
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if (response.isSuccessful()){
                    final String Result = response.body().string();

                    MainActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mtextvireresult.setText(Result);
                        }
                    });
                }
            }
        });
    }

    public void  LoginClicked(View view){
        setContentView(R.layout.activity_tasks);
    }

    public void  CreateTasks(View view){
        final TableLayout tableLayout = (TableLayout)findViewById(R.id.Tasks);
        final Context context = null;
        TableRow tableRow = new TableRow(context);
        // Set new table row layout parameters.
        TableRow.LayoutParams layoutParams = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT);
        tableRow.setLayoutParams(layoutParams);

        // Add a TextView in the first column.
        TextView textView = new TextView(context);
        textView.setText("This is the ");
        tableRow.addView(textView, 0);

        // Add a button in the second column
        Button button = new Button(context);
        button.setText("New Row");
        tableRow.addView(button, 1);

        // Add a checkbox in the third column.
        CheckBox checkBox = new CheckBox(context);
        checkBox.setText("Check it");
        tableRow.addView(checkBox, 2);

        tableLayout.addView(tableRow);
    }
}
